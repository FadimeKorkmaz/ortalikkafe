// HTML elementlerini seç
const menuContainer = document.getElementById('menu');
const buttons = document.querySelectorAll('.menu-links-inner button'); // Tüm butonları seç

// Başlık Haritası
const categoryTitles = {
  "aperatif": "APERATİFLER",
  "makarna": "MAKARNALAR",
  "tavuk": "TAVUKLAR",
  "burger": "BURGERLER",
  "pizza": "PİZZALAR",
  "et": "ETLER",
  "salata": "SALATALAR",
  "bira": "BİRALAR",
  "vodka": "VODKA",
  "cin": "CİN",
  "viski": "VİSKİLER",
  "tekila": "TEKİLA",
  "likor": "LİKÖRLER",
  "vermut": "VERMUTLAR",
  "rom": "ROM",
  "cognac": "KONYAK",
  "sarap": "ŞARAPLAR",
  "kokteyl": "KOKTEYLLER",
  "raki": "RAKILAR",
  "sicak-icecek": "SICAK İÇECEKLER",
  "mesrubat": "MEŞRUBATLAR",
  "meze": "MEZELER",
  "cerez": "ÇEREZLER"
};

function showCategory(catKey) {
  // --- 1. BUTON RENKLENDİRME (Aktif Olanı Seç) ---
  // Önce tüm butonlardaki 'active' sınıfını kaldır
  buttons.forEach(btn => btn.classList.remove('active'));
  
  // Tıklanan butonu bul ve 'active' yap
  // (HTML'deki onclick içindeki parametreye göre eşleştiriyoruz)
  buttons.forEach(btn => {
    if(btn.getAttribute('onclick').includes(catKey)) {
      btn.classList.add('active');
      // Mobilde seçilen butonu ekranın ortasına kaydır
      btn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  });

  // --- 2. İÇERİĞİ TEMİZLE ---
  menuContainer.innerHTML = '';

  // --- 3. VERİLERİ FİLTRELE ---
  const items = menuData.filter(item => item.category === catKey);

  if (items.length === 0) {
    menuContainer.innerHTML = '<p style="text-align:center; padding:20px; color:#666;">Bu kategoride henüz ürün bulunmuyor.</p>';
    return;
  }

  // --- 4. BAŞLIK EKLE ---
  const title = document.createElement('h2');
  title.innerText = categoryTitles[catKey] || catKey.toUpperCase();
  // Başlık stili (style.css'ten de alabilir ama garanti olsun)
  title.style.color = "var(--sarap-rengi)";
  title.style.textAlign = "center";
  title.style.borderBottom = "3px double var(--sarap-rengi)";
  title.style.paddingBottom = "10px";
  title.style.marginBottom = "20px";
  title.style.marginTop = "0";
  menuContainer.appendChild(title);

  // --- 5. LİSTEYİ OLUŞTUR ---
  items.forEach(item => {
    const card = document.createElement('div');
    card.classList.add('menu-item');

    card.innerHTML = `
      <div class="item-details">
        <h3>${item.name}</h3>
        <p class="item-desc">${item.desc}</p>
      </div>
      <div class="item-price">
        ${item.price}
      </div>
    `;
    menuContainer.appendChild(card);
  });
}

// Otomatik Başlat
document.addEventListener('DOMContentLoaded', () => {
  showCategory('aperatif');
});